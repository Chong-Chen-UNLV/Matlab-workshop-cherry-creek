function [numberOfNodes, procsPerNode, numberOfMpiProcs, memParam] = getCommonSelectParams(cluster, procsPerNode, environmentProperties)

assert(cluster.NumThreads<=procsPerNode, ...
       'ProcsPerNode (%d) must be greater than or equal to cluster.NumThreads (%d).', ...
       procsPerNode, cluster.NumThreads)

if cluster.NumThreads==procsPerNode
    numberOfNodes = environmentProperties.NumberOfTasks;
else
    % PPN > THREADS
    if environmentProperties.NumberOfTasks*cluster.NumThreads<=procsPerNode
        numberOfNodes = 1; procsPerNode = environmentProperties.NumberOfTasks*cluster.NumThreads;
    else
        % WORKERS*THREADS > PPN
        assert(mod(procsPerNode,cluster.NumThreads)==0, ...
               'ProcsPerNode (%d) must be multiple of cluster.NumThreads (%d).', ...
               procsPerNode, cluster.NumThreads)
        assert(mod(environmentProperties.NumberOfTasks*cluster.NumThreads,procsPerNode)==0, ...
               'NumberOfTasks (%d) and cluster.NumThreads (%d) must be multiple of ProcsPerNode (%d).', ...
               environmentProperties.NumberOfTasks, cluster.NumThreads, procsPerNode)

        numberOfNodes = environmentProperties.NumberOfTasks*cluster.NumThreads/procsPerNode;
    end
end

numberOfMpiProcs = procsPerNode/cluster.NumThreads;

% Maximum amount of memory used by a chunk
mu = validatedPropValue(cluster.AdditionalProperties, 'MemUsage', 'char', '');
if ~isempty(mu)
    mem = sscanf(mu,'%d%s');
    % nWorkers * memory per core, in size "units"
    memParam = sprintf(':mem=%d%s', procsPerNode * mem(1), mem(2:end));
else
    emsg = sprintf(['\n\t>> %% Must set MemUsage.  E.g.\n\n', ...
                    '\t>> c = parcluster;\n', ...
                    '\t>> c.AdditionalProperties.MemUsage = ''4GB'';\n', ...
                    '\t>> c.saveProfile\n\n']);
    error(emsg)
end


end