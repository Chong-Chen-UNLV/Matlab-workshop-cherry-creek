function remoteConnection = getRemoteConnection(cluster)
%GETREMOTECONNECTION Get a connected RemoteClusterAccess
%
% getRemoteConnection will either retrieve a RemoteClusterAccess from the
% cluster's UserData or it will create a new RemoteClusterAccess.

% Copyright 2010-2022 The MathWorks, Inc.

% Store the current filename for the dctSchedulerMessages
currFilename = mfilename;

if ~isprop(cluster.AdditionalProperties, 'ClusterHost')
    error('parallelexamples:GenericPBS:MissingAdditionalProperties', ...
        'Required field %s is missing from AdditionalProperties.', 'ClusterHost');
end
clusterHost = cluster.AdditionalProperties.ClusterHost;
if ~ischar(clusterHost) && ~(isstring(clusterHost) && isscalar(clusterHost))
    error('parallelexamples:GenericPBS:IncorrectArguments', ...
        'Hostname must be a character vector');
end

needToCreateNewConnection = false;
if isempty(cluster.UserData)
    needToCreateNewConnection = true;
else
    if ~isstruct(cluster.UserData)
        error('parallelexamples:GenericPBS:IncorrectUserData', ...
            ['Failed to retrieve remote connection from cluster''s UserData.\n' ...
            'Expected cluster''s UserData to be a structure, but found %s'], ...
            class(cluster.UserData));
    end
    
    if isfield(cluster.UserData, 'RemoteConnection')
        % Get the remote connection out of the cluster user data
        remoteConnection = cluster.UserData.RemoteConnection;
        
        % And check it is of the type that we expect
        if isempty(remoteConnection)
            needToCreateNewConnection = true;
        else
            clusterAccessClassname = 'parallel.cluster.RemoteClusterAccess';
            if ~isa(remoteConnection, clusterAccessClassname)
                error('parallelexamples:GenericPBS:IncorrectArguments', ...
                    ['Failed to retrieve remote connection from cluster''s UserData.\n' ...
                    'Expected the RemoteConnection field of the UserData to contain an object of type %s, but found %s.'], ...
                    clusterAccessClassname, class(remoteConnection));
            end
            
            if ~remoteConnection.IsConnected
                needToCreateNewConnection = true;
            elseif ~strcmpi(remoteConnection.Hostname, clusterHost)
                % The connection stored in the user data does not match the cluster host requested
                warning('parallelexamples:GenericPBS:DifferentRemoteParameters', ...
                    ['The current cluster is already using cluster host.\n', ...
                    'The existing connection to %s will be replaced.'], ...
                    remoteConnection.Hostname, remoteConnection.Hostname);
                cluster.UserData.RemoteConnection = [];
                needToCreateNewConnection = true;
            end
        end
    else
        needToCreateNewConnection = true;
    end
end

if ~needToCreateNewConnection
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CUSTOMIZATION MAY BE REQUIRED %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the credential options from the user using simple
% MATLAB dialogs or command line input.  You should change
% this section if you wish for users to provide their credential
% options in a different way.
% The pertinent options are:
% username - The username you use when you run commands on the remote host
% authMode - Authentication mode you use when you connect to the cluster.
%   Supported options are:
%   'Password' - Enter your SSH password when prompted by MATLAB.
%   'IdentityFile' - Use an identity file on disk.
%   'Agent' - Interface with an SSH agent running on the client machine.
%             Supported in R2021b onwards.
%   'Multifactor' - Enable the cluster to prompt you for input one or more
%                   times. If two-factor authentication (2FA) is enabled on
%                   the cluster, the cluster will request your password and
%                   a response for the second authentication factor.
%                   Supported in R2022a onwards.
% identityFile - Full path to the identity file.
% identityFileHasPassphrase - True if the identity file requires a passphrase
%                             (true/false).

% Use the UI for prompts if MATLAB has been started with the desktop enabled
useUI = desktop('-inuse');
username = iGetUsername(cluster, useUI);

% Decide which authentication mode to use
% Default mechanism is to prompt for password
authMode = 'Password';
if isprop(cluster.AdditionalProperties, 'AuthenticationMode')
    % If AdditionalProperties.AuthenticationMode is defined, use that
    authMode = cluster.AdditionalProperties.AuthenticationMode;
elseif isprop(cluster.AdditionalProperties, 'UseIdentityFile')
    % Otherwise use an identity file if UseIdentityFile is defined and true
    useIdentityFile = cluster.AdditionalProperties.UseIdentityFile;
    if ~islogical(useIdentityFile) || ~isscalar(useIdentityFile)
        error('parallelexamples:GenericPBS:IncorrectArguments', ...
            'UseIdentityFile must be a logical scalar');
    end
    if useIdentityFile
        authMode = 'IdentityFile';
    end
elseif isprop(cluster.AdditionalProperties, 'IdentityFile')
    % Otherwise use an identity file if IdentityFile is defined
    authMode = 'IdentityFile';
else
    % Otherwise nothing is specified, ask the user what to do
    authMode = iPromptUserForAuthenticationMode(cluster, useUI);
end

% Build the user arguments to pass to RemoteClusterAccess
userArgs = {username};
if verLessThan('matlab', '9.11')
    if ~ischar(authMode) || ~ismember(authMode, {'IdentityFile', 'Password'})
        % Prior to R2021b, only IdentityFile and Password are supported
        error('parallelexamples:GenericPBS:IncorrectArguments', ...
            'AuthenticationMode must be either ''IdentityFile'' or ''Password''');
    end
else
    % No need to validate authMode, RemoteClusterAccess will do that for us
    userArgs = [userArgs, 'AuthenticationMode', {authMode}];
end

% If using identity file, also need the filename and whether a passphrase is needed
if any(strcmp(authMode, 'IdentityFile'))
    identityFile = iGetIdentityFile(cluster, useUI);
    identityFileHasPassphrase = iGetIdentityFileHasPassphrase(cluster, useUI);
    userArgs = [userArgs, 'IdentityFilename', {identityFile}, ...
        'IdentityFileHasPassphrase', identityFileHasPassphrase];
end

cluster.saveProfile

% Now connect and store the connection
dctSchedulerMessage(1, '%s: Connecting to remote host %s', ...
    currFilename, clusterHost);
remoteConnection = parallel.cluster.RemoteClusterAccess.getConnectedAccess(clusterHost, userArgs{:});
dctSchedulerMessage(5, '%s: Storing remote connection in cluster''s user data.', currFilename);
cluster.UserData.RemoteConnection = remoteConnection;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function username = iGetUsername(cluster, useUI)

if isprop(cluster.AdditionalProperties, 'Username')
    username = cluster.AdditionalProperties.Username;
    if ~ischar(username) && ~(isstring(username) && isscalar(username))
        error('parallelexamples:GenericPBS:IncorrectArguments', ...
            'Username must be a character vector');
    end
    return
end

if useUI
    dlgMessage = sprintf('Enter the username for %s', cluster.AdditionalProperties.ClusterHost);
    dlgTitle = 'User Credentials';
    numlines = 1;
    usernameResponse = inputdlg(dlgMessage, dlgTitle, numlines);
    % Hitting cancel gives an empty cell array, but a user providing an empty string gives
    % a (non-empty) cell array containing an empty string
    if isempty(usernameResponse)
        % User hit cancel
        error('parallelexamples:GenericPBS:UserCancelledOperation', ...
            'User cancelled operation.');
    end
    username = char(usernameResponse);
    cluster.AdditionalProperties.Username = username;
    return
end

% useUI == false
username = input(sprintf('Enter the username for %s:\n', cluster.AdditionalProperties.ClusterHost), 's');
cluster.AdditionalProperties.Username = username;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function identityFileHasPassphrase = iGetIdentityFileHasPassphrase(cluster, useUI)

if isprop(cluster.AdditionalProperties, 'IdentityFileHasPassphrase')
    identityFileHasPassphrase = cluster.AdditionalProperties.IdentityFileHasPassphrase;
    if ~islogical(identityFileHasPassphrase)
        error('parallelexamples:GenericPBS:IncorrectArguments', ...
            'IdentityFileHasPassphrase must be a logical scalar');
    end
    return
end

if useUI
    dlgMessage = 'Does the identity file require a password?';
    dlgTitle = 'User Credentials';
    passphraseResponse = questdlg(dlgMessage, dlgTitle);
    if strcmp(passphraseResponse, 'Cancel')
        % User hit cancel
        error('parallelexamples:GenericPBS:UserCancelledOperation', 'User cancelled operation.');
    end
    identityFileHasPassphrase = strcmp(passphraseResponse, 'Yes');
    cluster.AdditionalProperties.IdentityFileHasPassphrase = identityFileHasPassphrase;
    return
end

% useUI == false
validYesNoResponse = {'y', 'n'};
passphraseMessage = 'Does the identity file require a password? (y or n)\n';
passphraseResponse = iLoopUntilValidStringInput(passphraseMessage, validYesNoResponse);
identityFileHasPassphrase = strcmpi(passphraseResponse, 'y');
cluster.AdditionalProperties.IdentityFileHasPassphrase = identityFileHasPassphrase;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function identityFile = iGetIdentityFile(cluster, useUI)

% MW: We're using 'remote' because Cherry Creek doesn't allow for job submission on the compute node.
% Therefore, in order to run in this in batch mode, we can't request the username, user's
% password, or user's phassphrase of a private key.  We can only use their private key and it
% must be in a well known location.
home = getenv('HOME');
identityFile = fullfile(home,'.ssh','id_rsa');
if exist(identityFile,'file')==false
    error('Failed to find priviate key: %s', identityFile)
end
return

if isprop(cluster.AdditionalProperties, 'IdentityFile')
    identityFile = cluster.AdditionalProperties.IdentityFile;
    if ~(ischar(identityFile) || isstring(identityFile) || iscellstr(identityFile)) || any(strlength(identityFile) == 0)
        error('parallelexamples:GenericPBS:IncorrectArguments', ...
            'Each IdentityFile must be a nonempty character vector');
    end
else
    if useUI
        dlgMessage = 'Select Identity File to use';
        [filename, pathname] = uigetfile({'*.*', 'All Files (*.*)'},  dlgMessage);
        % If the user hit cancel, then filename and pathname will both be 0.
        if isequal(filename, 0) && isequal(pathname,0)
            error('parallelexamples:GenericPBS:UserCancelledOperation', 'User cancelled operation.');
        end
        identityFile = fullfile(pathname, filename);
        cluster.AdditionalProperties.IdentityFile = identityFile;
    else
        identityFile = input(sprintf('Please enter the full path to the Identity File to use:\n'), 's');
        cluster.AdditionalProperties.IdentityFile = identityFile;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function authMode = iPromptUserForAuthenticationMode(cluster, useUI)
if useUI
    dlgMessage = sprintf('Use an identity file to login to %s?', cluster.AdditionalProperties.ClusterHost);
    dlgTitle = 'User Credentials';
    identityFileResponse = questdlg(dlgMessage, dlgTitle);
    if strcmp(identityFileResponse, 'Cancel')
        % User hit cancel
        error('parallelexamples:GenericPBS:UserCancelledOperation', 'User cancelled operation.');
    end
    useIdentityFile = strcmp(identityFileResponse, 'Yes');
    cluster.AdditionalProperties.UseIdentityFile = useIdentityFile;
else
    validYesNoResponse = {'y', 'n'};
    identityFileMessage = sprintf('Use an identity file to login to %s? (y or n)\n', cluster.AdditionalProperties.ClusterHost);
    identityFileResponse = iLoopUntilValidStringInput(identityFileMessage, validYesNoResponse);
    useIdentityFile = strcmpi(identityFileResponse, 'y');
    cluster.AdditionalProperties.UseIdentityFile = useIdentityFile;
end

if useIdentityFile
    authMode = 'IdentityFile';
else
    authMode = 'Password';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function returnValue = iLoopUntilValidStringInput(message, validValues)
% Function to loop until a valid response is obtained user input
returnValue = '';

while isempty(returnValue) || ~any(strcmpi(returnValue, validValues))
    returnValue = input(message, 's');
end
